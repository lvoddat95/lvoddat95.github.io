function toggleClass(el, className) {
    el.classList.toggle(className);
}
